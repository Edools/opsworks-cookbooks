#
# Cookbook:: heimdall
# Recipe:: default
#
# Copyright:: 2020, The Authors, All Rights Reserved.

node.default['packages-cookbook'] = [
 'nodejs',
 'imagemagick'
]