require 'serverspec'

set :backend, :cmd
set :os, family: 'windows'
