Changes
=======

0.3.0
-----

 - Drop `install_ruby_dev` attribute, add `ruby-ng::dev` recipe instead

0.2.0
-----

 - Default to Ruby 2.1
 - Switch to install ruby-dev
 - Don't install rubygems package


0.1.1 and before
----------------
(history would need to be reconstructed)
